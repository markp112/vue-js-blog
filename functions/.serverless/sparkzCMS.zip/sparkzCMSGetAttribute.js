const AWS = require("aws-sdk");

const response ={
    statusCode: 200,
    headers: {
      "Access-Control-Allow-Origin": "*"
    },
    body: JSON.stringify({ message: "Hello World" })
  }


exports.handler  = async (event, context, callback) => {

    const key = event.key
    const sortkey = event.sortkey

    if(key == undefined || sortkey == undefined){
        response.statusCode = 400
        response.body = JSON.stringify({message : "Missing or invalid parameters"})
        callback(response)
        return 
    }

    const params ={
        TableName:"sparkzCMS",
        Key:{
            mainAttribute: key,
            subAttribute: sortKey
        },
        ConsistentRead: false
    }

    const data = await docClient.get(params).promise()
    .then(data =>{
        response.body = JSON.stringify({data})
        callback(null,response)
        return 
    })
    .catch (err =>{
        response.statusCode = 500
        response.body = JSON.stringify({message: err.message})
        callback(response );
        return
    })


  
};